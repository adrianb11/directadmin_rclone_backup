<script type="text/javascript">
    window.onload = function () {
        document.getElementById('iframe-container').style.width = '100%'
    }
</script>