<div class="tab-content">
    <div class="tab-pane active">
        <?php include('pages/' . $tab . '.php'); ?>
    </div>
</div>