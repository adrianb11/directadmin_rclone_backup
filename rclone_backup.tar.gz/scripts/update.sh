#!/bin/sh

echo "Plugin has been updated!" #NOT! :)

exit 0
